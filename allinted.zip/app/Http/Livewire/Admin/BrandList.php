<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class BrandList extends Component
{
    public function render()
    {
        return view('livewire.admin.brand-list');
    }
}
