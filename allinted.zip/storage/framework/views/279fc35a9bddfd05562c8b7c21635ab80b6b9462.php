<div>
    
</div>
<?php /**PATH C:\xampp\htdocs\allinted\resources\views/livewire/admin/category-list.blade.php ENDPATH**/ ?>