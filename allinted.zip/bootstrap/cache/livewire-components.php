<?php return array (
  'admin.brand-list' => 'App\\Http\\Livewire\\Admin\\BrandList',
  'admin.category-list' => 'App\\Http\\Livewire\\Admin\\CategoryList',
  'admin.modelo-list' => 'App\\Http\\Livewire\\Admin\\ModeloList',
  'admin.product-create' => 'App\\Http\\Livewire\\Admin\\ProductCreate',
  'admin.product-list' => 'App\\Http\\Livewire\\Admin\\ProductList',
  'admin.purchase-create' => 'App\\Http\\Livewire\\Admin\\PurchaseCreate',
  'admin.purchase-list' => 'App\\Http\\Livewire\\Admin\\PurchaseList',
);